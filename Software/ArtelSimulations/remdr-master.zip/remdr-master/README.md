# remdr
Remote EMDR

## Some cool sites
* https://wiki.gentoo.org/wiki/Sony_DualShock
* https://jstest-gtk.gitlab.io/
* joystick-support fedora
* https://blakerohde.com/blog/2012/06/gamepads-joysticks-on-fedora-17/
* https://www.pygame.org/docs/ref/joystick.html
* https://pypi.org/project/joystick/
* https://pypi.org/project/inputs/
* https://python-evdev.readthedocs.io/en/latest/tutorial.html#create-uinput-device-capable-of-recieving-ff-effects
* https://android.googlesource.com/kernel/common.git/+/brillo-m9-release/drivers/hid/hid-sony.c
* https://www.kernel.org/doc/html/latest/input/ff.html
* https://github.com/flosse/linuxconsole/blob/master/utils/fftest.c
* How to send a rumble effect to a device using python evdev - Stack Overflow	https://stackoverflow.com/questions/33201711/how-to-send-a-rumble-effect-to-a-device-using-python-evdev
* gamepad - Control vibration motors of game controller in pure Python? - Stack Overflow	https://stackoverflow.com/questions/49968540/control-vibration-motors-of-game-controller-in-pure-python	
API Reference Python-evdev	https://python-evdev.readthedocs.io/en/latest/apidoc.html
* Force feedback for Linux The Linux Kernel documentation https://www.kernel.org/doc/html/latest/input/ff.html	

## Next steps
* Periodic vs Rumble
* Gain

