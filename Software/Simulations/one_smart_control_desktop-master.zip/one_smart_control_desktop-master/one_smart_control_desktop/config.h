#include <QVersionNumber>

#ifndef CONFIG_H
#define CONFIG_H

namespace OneSmartControl
{

static QVersionNumber version(0,3);

}

#endif // CONFIG_H
